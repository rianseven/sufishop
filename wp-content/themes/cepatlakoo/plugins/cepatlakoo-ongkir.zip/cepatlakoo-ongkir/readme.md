<h1>Cepatlakoo Ongkir (WooCommerce Shipping Method Add-on)</h1>

<p>This is additional shipping methods for indonesian wordpress based e-commerce. This plugin using <a href="htpp://rajaongkir.com">rajaongkir.com</a> API.</p>

<h2>How to Install</h2>
<ol>
  <li>Install WooCommerce plugin on your Wordpress site.</li>
  <li>Install this add-on plugin.</li>
  <li>Go <a href="http://rajaongkir.com/akun/daftar">sign up</a> on rajaongkir.com for API key.</li>
  <li>When you get the API key, go to WooCommerce menu then hit "General" tab, find and fill "RajaOngkir API Key" field with your API key</li>
  <li>Go to "Shipping" tab, and "myongkir shipping" section to choose your base city. <br><i>Note: before you choose the city base, ensure that you have set the woocommerce base country to indonesian state/province, e.g: Indonesia-DKI Jakarta.</i></li>
  <li>Check "Enable this shipping method" option.</li>
  <li>Now, your products can be shipped by various indonesian couriers!</li>
</ol>

<h2>Todo</h2>
<ol>
  <li>Order's minimum weight</li>
  <li>Weight validation on add product, don't save product if weight is empty</li>
</ol>

<h2>Note</h2>
<p>Please put weight for every product. It will affect the shipping cost.</p>
<p>Contact me if you found some bugs. Thanks.</p>

<h2>Lisence</h2>
<p>MIT License &copy; 2014 eezhal<p>
